package taller1;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class TrazadoresCubicosTaller24 {
	public static void main(String[] args) {
		Scanner entrada=new Scanner(System.in);

		double[] x = {1, 2, 3, 4, 5, 6, 7};
		double[] y = {1.4, 1.8, 2, 1.8, 0.4, 1.2, 3.4};
		int n = x.length;

		//se crea la matriz de los trazadores
		double[][] a = new double[n - 2][n - 2];
		double[] b = new double[n - 2];

		for (int i = 1; i < n - 1; i++) {
			if (i > 1) {
				a[i - 1][i - 2] = x[i] - x[i - 1];
			}
			a[i - 1][i - 1] = 2 * (x[i + 1] - x[i - 1]);
			if (i < n - 2) {
				a[i - 1][i] = x[i + 1] - x[i];
			}
			b[i - 1] = (6 / (x[i + 1] - x[i])) * (y[i + 1] - y[i]) + (6 / (x[i] - x[i - 1]) * (y[i - 1] - y[i]));
		}

		double[] rtaAux = gaussJordan(a, b);
		double[] f2 = new double[n];
		System.arraycopy(rtaAux, 0, f2, 1, rtaAux.length);

		for (int i = 1; i < n; i++) {
			double t1 = f2[i - 1] / (6 * (x[i] - x[i - 1]));
			double t2 = f2[i] / (6 * (x[i] - x[i - 1]));
			double t3 = y[i - 1] / (x[i] - x[i - 1]) - f2[i - 1] * (x[i] - x[i - 1]) / 6;
			double t4 = y[i] / (x[i] - x[i - 1]) - f2[i] * (x[i] - x[i - 1]) / 6;

			double[] arrCoef = new double[4];

			//Se calculan los coeficientes del polinomio
			arrCoef[0] = t1 * Math.pow(x[i], 3) - t2 * Math.pow(x[i - 1], 3) + t3 * x[i] - t4 * x[i - 1];
			arrCoef[1] = -t1 * 3 * Math.pow(x[i], 2) + t2 * 3 * Math.pow(x[i - 1], 2) - t3 + t4;
			arrCoef[2] = t1 * 3 * x[i] - t2 * 3 * x[i - 1];
			arrCoef[3] = -t1 + t2;

			System.out.print("f(x) = ");
			for (int j = 0; j < 4; j++) {
				if (arrCoef[j] != 0) {
					if (j > 0) {
						System.out.print("+ ");
					}
					System.out.print(arrCoef[j]);
					switch (j) {
					case 0:
						System.out.print(" ");
						break;
					case 1:
						System.out.print("x ");
						break;
					default:
						System.out.print("x^" + j + " ");
						break;
					}
				}
			}
			System.out.println("{x>=" + x[i - 1] + "}{x<" + x[i] + "}");
			
		}
		
		

		double valor= 4.25;
		double total=0;

		System.out.print("\n");
		
		for (int i = 1; i < n; i++) {
			double t1 = f2[i - 1] / (6 * (x[i] - x[i - 1]));
			double t2 = f2[i] / (6 * (x[i] - x[i - 1]));
			double t3 = y[i - 1] / (x[i] - x[i - 1]) - f2[i - 1] * (x[i] - x[i - 1]) / 6;
			double t4 = y[i] / (x[i] - x[i - 1]) - f2[i] * (x[i] - x[i - 1]) / 6;

			double[] arrCoef = new double[4];

			//Se calculan los coeficientes del polinomio
			arrCoef[0] = t1 * Math.pow(x[i], 3) - t2 * Math.pow(x[i - 1], 3) + t3 * x[i] - t4 * x[i - 1];
			arrCoef[1] = -t1 * 3 * Math.pow(x[i], 2) + t2 * 3 * Math.pow(x[i - 1], 2) - t3 + t4;
			arrCoef[2] = t1 * 3 * x[i] - t2 * 3 * x[i - 1];
			arrCoef[3] = -t1 + t2;

			System.out.print("f(x) = ");
			for (int j = 0; j < 4; j++) {
				if (arrCoef[j] != 0) {
					if(j>0) {
					total=total+(arrCoef[j]*Math.pow(valor, j));
					}
				}
			}
			System.out.print(total);
			System.out.println("{x>=" + x[i - 1] + "}{x<" + x[i] + "}");
			
		}
		
		System.out.print("\n");
		for (int i = 1; i < n; i++) {
			double t1 = f2[i - 1] / (6 * (x[i] - x[i - 1]));
			double t2 = f2[i] / (6 * (x[i] - x[i - 1]));
			double t3 = y[i - 1] / (x[i] - x[i - 1]) - f2[i - 1] * (x[i] - x[i - 1]) / 6;
			double t4 = y[i] / (x[i] - x[i - 1]) - f2[i] * (x[i] - x[i - 1]) / 6;

			double[] arrCoef = new double[4];

			//Se calculan los coeficientes del polinomio
			arrCoef[0] = t1 * Math.pow(x[i], 3) - t2 * Math.pow(x[i - 1], 3) + t3 * x[i] - t4 * x[i - 1];
			arrCoef[1] = -t1 * 3 * Math.pow(x[i], 2) + t2 * 3 * Math.pow(x[i - 1], 2) - t3 + t4;
			arrCoef[2] = t1 * 3 * x[i] - t2 * 3 * x[i - 1];
			arrCoef[3] = -t1 + t2;

			System.out.print("f'(x) = ");
			for (int j = 0; j < 4; j++) {
				if (arrCoef[j] != 0) {
					if (j > 1) {
						System.out.print(" + ");
					}
					if(j>0) {
					System.out.print(arrCoef[j]*j);
					}
					switch (j) {
					case 0:
						System.out.print(" ");
						break;
					case 1:
						System.out.print(" ");
						break;
					case 2:
						System.out.print("x ");
						break;
					default:
						System.out.print("x^" + (j-1 )+ " ");
						break;
					}
				}
			}
			System.out.println("{x>=" + x[i - 1] + "}{x<" + x[i] + "}");
			
		}

		System.out.print("\n");
		for (int i = 1; i < n; i++) {
			double t1 = f2[i - 1] / (6 * (x[i] - x[i - 1]));
			double t2 = f2[i] / (6 * (x[i] - x[i - 1]));
			double t3 = y[i - 1] / (x[i] - x[i - 1]) - f2[i - 1] * (x[i] - x[i - 1]) / 6;
			double t4 = y[i] / (x[i] - x[i - 1]) - f2[i] * (x[i] - x[i - 1]) / 6;

			double[] arrCoef = new double[4];

			//Se calculan los coeficientes del polinomio
			arrCoef[0] = t1 * Math.pow(x[i], 3) - t2 * Math.pow(x[i - 1], 3) + t3 * x[i] - t4 * x[i - 1];
			arrCoef[1] = -t1 * 3 * Math.pow(x[i], 2) + t2 * 3 * Math.pow(x[i - 1], 2) - t3 + t4;
			arrCoef[2] = t1 * 3 * x[i] - t2 * 3 * x[i - 1];
			arrCoef[3] = -t1 + t2;

			System.out.print("f''(x) = ");
			for (int j = 0; j < 4; j++) {
				if (arrCoef[j] != 0) {
					if (j > 2) {
						System.out.print(" + ");
					}
					if(j>1) {
					System.out.print(arrCoef[j]*j*(j-1));
					}
					switch (j) {
					case 0:
						System.out.print(" ");
						break;
					case 1:
						System.out.print(" ");
						break;
					case 2:
						System.out.print(" ");
						break;
					case 3:
						System.out.print("x ");
						break;
					default:
						System.out.print("x^" + (j-2 )+ " ");
						break;
					}
				}
			}
			System.out.println("{x>=" + x[i - 1] + "}{x<" + x[i] + "}");
			
		}
		
		System.out.print("\n");
		for (int i = 1; i < n; i++) {
			double t1 = f2[i - 1] / (6 * (x[i] - x[i - 1]));
			double t2 = f2[i] / (6 * (x[i] - x[i - 1]));
			double t3 = y[i - 1] / (x[i] - x[i - 1]) - f2[i - 1] * (x[i] - x[i - 1]) / 6;
			double t4 = y[i] / (x[i] - x[i - 1]) - f2[i] * (x[i] - x[i - 1]) / 6;

			double[] arrCoef = new double[4];

			//Se calculan los coeficientes del polinomio
			arrCoef[0] = t1 * Math.pow(x[i], 3) - t2 * Math.pow(x[i - 1], 3) + t3 * x[i] - t4 * x[i - 1];
			arrCoef[1] = -t1 * 3 * Math.pow(x[i], 2) + t2 * 3 * Math.pow(x[i - 1], 2) - t3 + t4;
			arrCoef[2] = t1 * 3 * x[i] - t2 * 3 * x[i - 1];
			arrCoef[3] = -t1 + t2;

			System.out.print("f'''(x) = ");
			for (int j = 0; j < 4; j++) {
				if (arrCoef[j] != 0) {
					if (j > 3) {
						System.out.print(" + ");
					}
					if(j>2) {
					System.out.print(arrCoef[j]*j*(j-1)*(j-2));
					}
					switch (j) {
					case 0:
						System.out.print(" ");
						break;
					case 1:
						System.out.print(" ");
						break;
					case 2:
						System.out.print(" ");
						break;
					case 3:
						System.out.print(" ");
						break;
					case 4:
						System.out.print("x ");
						break;
					default:
						System.out.print("x^" + (j-3 )+ " ");
						break;
					}
				}
			}
			System.out.println("{x>=" + x[i - 1] + "}{x<" + x[i] + "}");
			
		}
		
		
	}

	private static double[] gaussJordan(double[][] a, double[] b) {
		double[][] aAux = duplicarArreglo(a);
		double[] bAux = duplicarArreglo(b);

		int n = bAux.length;

		//Se construye la matriz triangular superior
		for (int i = 0; i < n; i++) {
			//Pivoteo
			if (aAux[i][i] == 0) {
				for (int k = i + 1; k < n; k++) {
					if (aAux[k][i] != 0) {
						double[] filaAux = aAux[i];
						aAux[i] = aAux[k];
						aAux[k] = filaAux;

						double valoAux = bAux[i];
						bAux[i] = bAux[k];
						bAux[k] = valoAux;
						break;
					}
				}
			}

			//Escalonamiento
			double valorAux = aAux[i][i];
			for (int j = i; j < n; j++) {
				aAux[i][j] /= valorAux;
			}
			bAux[i] /= valorAux;

			//Reducci�n
			for (int j = 0; j < n; j++) {
				if (j != i) {
					double fact = aAux[j][i] / aAux[i][i];

					for (int k = 0; k < n; k++) {
						aAux[j][k] -= (aAux[i][k] * fact);
					}

					bAux[j] -= (bAux[i] * fact);
				}
			}
		}

		return bAux;
	}

	private static double[][] duplicarArreglo(double[][] m) {
		double[][] duplicado = new double[m.length][m[0].length];
		for (int i = 0; i < m.length; i++) {
			System.arraycopy(m[i], 0, duplicado[i], 0, m[i].length);
		}

		return duplicado;
	}

	private static double[] duplicarArreglo(double[] v) {
		double[] duplicado = new double[v.length];
		System.arraycopy(v, 0, duplicado, 0, v.length);

		return duplicado;
	}

}