package taller1;

import java.util.Scanner;
import taller1.Gausjordan;

public class Taller21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double x1ala2=0;
		double sumatoriax1=0;
		double sumatoriax1ala2=0;
		double promediox1=0;
		double sumatoriax2=0;
		double promediox2=0;
		double multiplicacionx1yx2=0;
		double sumatoriamultiplicacionx1yx2=0;
		double x2ala2=0;
		double sumatoriax2ala2=0;
		double sumatoriay=0;
		double promedioy=0;
		double multiplicacionx1y=0;
		double sumatoriamultiplicacionx1y=0;
		double multiplicacionx2y=0;
		double sumatoriamultiplicacionx2y=0;
		int n=0;
		double a0=0;
		double a1=0;
		double a2=0;
		double st=0;
		double sr=0;
		double sumatoriast=0;
		double sumatoriasr=0;
		double r=0;

		Scanner sc = new Scanner(System.in);
		double x1[]= {0,0,1,2,0,1,2,2};
		double x2[]= {0,1,1,2,2,3,3,1};
		double y[]= {3.2,6,2.2,2.4,6.4,6.6,3.4,0.2};

		for(int i =0; i<x1.length;i++) {
			sumatoriax1=sumatoriax1+x1[i];
			x1ala2=Math.pow(x1[i], 2);
			sumatoriax1ala2=x1ala2+sumatoriax1ala2;
			n++;
			multiplicacionx1yx2=x1[i]*x2[i];
			sumatoriamultiplicacionx1yx2=sumatoriamultiplicacionx1yx2+multiplicacionx1yx2;
		}promediox1=sumatoriax1/x1.length;

		for(int i =0; i<x2.length;i++) {
			sumatoriax2=sumatoriax2+x2[i];
			x2ala2=Math.pow(x2[i], 2);
			sumatoriax2ala2=sumatoriax2ala2+x2ala2;
		}promediox2=sumatoriax2/x2.length;

		for(int i=0; i<y.length;i++) {
			sumatoriay=sumatoriay+y[i];
			multiplicacionx1y=x1[i]*y[i];
			sumatoriamultiplicacionx1y=sumatoriamultiplicacionx1y+multiplicacionx1y;
			multiplicacionx2y=x2[i]*y[i];
			sumatoriamultiplicacionx2y=sumatoriamultiplicacionx2y+multiplicacionx2y;
			
			st=Math.pow(y[i]-promedioy, 2);
			sumatoriast=sumatoriast+st;
			
		}promedioy=sumatoriay/y.length;
		
		System.out.println(n+"a0 +"+sumatoriax1+"a1 + "+sumatoriax2+"a2 = "+sumatoriay);
		System.out.println(sumatoriax1+"a0 + "+sumatoriax1ala2+"a1 + "+sumatoriamultiplicacionx1yx2+"a2 = "+sumatoriamultiplicacionx1y);
		System.out.println(sumatoriax2+"a0 + "+sumatoriamultiplicacionx1yx2+"a1 + "+sumatoriax2ala2+"a2 = "+sumatoriamultiplicacionx2y);
		

		double[][] a = {{n, sumatoriax1, sumatoriax2}, {sumatoriax1, sumatoriax1ala2, sumatoriamultiplicacionx1yx2}, {sumatoriax2, sumatoriamultiplicacionx1yx2, sumatoriax2ala2}};
		double[] b = {sumatoriay, sumatoriamultiplicacionx1y, sumatoriamultiplicacionx2y};

		double[] gaus = gaussJordan(a, b);

		//Se imprimen los resultados
		for (int i = 0; i < gaus.length; i++) {
			System.out.println("a" + (i ) + " = " + gaus[i]);
			if (i==0) {
				a0=gaus[i];
			}if (i==1) {
				a1=gaus[i];
			}if (i==2) {
				a2=gaus[i];}
		}
		
		for(int i =0; i<y.length;i++) {
			sr=Math.pow(y[i]-a0-a1*x1[i]-a2*x2[i], 2);
			sumatoriasr=sumatoriasr+sr;}
			
			r=Math.pow(((sumatoriast-sumatoriasr)/sumatoriast), 0.5)*100;
			
			System.out.println("r = "+r+"%");
			System.out.println("y = ("+a0+") + ("+a1+")x1 + ("+a2+")x2");
			System.out.println("z = ("+a0+") + ("+a1+")x + ("+a2+")y");}

	

	private static double[] gaussJordan(double[][] a, double[] b) {
		double[][] aAux = duplicarArreglo(a);
		double[] bAux = duplicarArreglo(b);

		int n = bAux.length;
		//Se construye la matriz identidad
		for (int i = 0; i < n; i++) {
			//Pivoteo
			if (aAux[i][i] == 0) {
				int indiceAux = i;
				for (int j = i + 1; j < n; j++) {
					if (aAux[j][i] != 0) {
						indiceAux = j;
						break;
					}
				}
				if (indiceAux != i) {
					double[] filaAux = aAux[i];
					aAux[i] = aAux[indiceAux];
					aAux[indiceAux] = filaAux;

					double valoAux = bAux[i];
					bAux[i] = bAux[indiceAux];
					bAux[indiceAux] = valoAux;
				}
			}

			//Normalizaci�n
			double divisorAux = aAux[i][i];
			for (int j = 0; j < n; j++) {
				aAux[i][j] /= divisorAux;
			}
			bAux[i] /= divisorAux;

			//Reducci�n
			for (int j = 0; j < n; j++) {
				if (i != j) {
					double fact = -aAux[j][i] / aAux[i][i];

					for (int k = 0; k < n; k++) {
						aAux[j][k] += (aAux[i][k] * fact);
					}

					bAux[j] += (bAux[i] * fact);
				}
			}
		}

		return bAux;
	}

	private static double[][] duplicarArreglo(double[][] m) {
		double[][] duplicado = new double[m.length][m[0].length];
		for (int i = 0; i < m.length; i++) {
			System.arraycopy(m[i], 0, duplicado[i], 0, m[i].length);
		}

		return duplicado;
	}

	private static double[] duplicarArreglo(double[] v) {
		double[] duplicado = new double[v.length];
		System.arraycopy(v, 0, duplicado, 0, v.length);

		return duplicado;
	}

	private static void imprimirEcuaciones(double[][] a, double[] b) {

		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println("| " + b[i]);
		}
	}



}
