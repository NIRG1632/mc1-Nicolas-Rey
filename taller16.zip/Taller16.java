package taller1;

import java.util.Scanner;

public class Taller16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double sumatoriax=0;
		double sumatoriay=0;
		double xporx=0;
		double sumatoriax2=0;
		double promediox=0;
		double promedioy=0;
		double multiplicacion=0;
		double sumatoriamultiplicacion=0;
		double a1=0;
		double a0=0;
		
		
		Scanner sc = new Scanner(System.in);
		int x[]= {0,1,3,5,6,8,9,12};
		int y[]= {14,10,12,6,8,5,4,1};
		
		for(int i =0; i<x.length;i++) {
			sumatoriax=sumatoriax+x[i];
			xporx=x[i]*x[i];
			sumatoriax2=xporx+sumatoriax2;
		}
		promediox=sumatoriax/x.length;
		
				
		for(int i =0; i<y.length;i++) {
			sumatoriay=sumatoriay+y[i];
		}
		promedioy=sumatoriay/y.length;
		
		for(int i=0; i<x.length;i++) {
			multiplicacion=x[i]*y[i];
			sumatoriamultiplicacion=sumatoriamultiplicacion+multiplicacion;
		}
		a1=(x.length*sumatoriamultiplicacion-sumatoriax*sumatoriay)/(x.length*sumatoriax2-(sumatoriax*sumatoriax));
		a0=promedioy-a1*promediox;
		System.out.println(" ao = " +a0);
		System.out.println(" a1 = " +a1);
		
		System.out.println(a0 + " + " + a1 + "x");
	}
	}
