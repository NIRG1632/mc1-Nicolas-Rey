package taller1;

import java.util.Scanner;

public class Taller18A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double sumatoria1divx=0;
		double sumatoria1divy=0;
		double cuadrado1divx=0;
		double sumatoria1divx2=0;
		double promediox=0;
		double promedioy=0;
		double multiplicacion=0;
		double sumatoriamultiplicacion=0;
		double a1=0;
		double a0=0;
		double alpha=0;
		double beta=0;
		
		
		Scanner sc = new Scanner(System.in);
		double x[]= {2,3,4,5,6,7,8,9,10};
		double y[]= {1,1.2,1.5,2.1,2.8,3.8,5,6.5,8.5};
		
		
		for(int i =0; i<x.length;i++) {
			sumatoria1divx=sumatoria1divx+1/x[i];
			cuadrado1divx=1/x[i]*1/x[i];
			sumatoria1divx2=cuadrado1divx+sumatoria1divx2;
		}
		promediox=sumatoria1divx/x.length;
		
				
		for(int i =0; i<y.length;i++) {
			sumatoria1divy=sumatoria1divy+1/y[i];
		}
		promedioy=sumatoria1divy/y.length;
		
		for(int i=0; i<x.length;i++) {
			multiplicacion=1/x[i]*1/y[i];
			sumatoriamultiplicacion=sumatoriamultiplicacion+multiplicacion;
		}
		
		
		a1=(x.length*sumatoriamultiplicacion-sumatoria1divx*sumatoria1divy)/(x.length*sumatoria1divx2-(sumatoria1divx*sumatoria1divx));
		a0=promedioy-a1*promediox;
		System.out.println(" ao = " +a0);
		System.out.println(" a1 = " +a1);
		alpha=1/a0;
		beta=a1/a0;
		System.out.println("se aplica la transformacion");
		System.out.println("alpha =" + alpha);
		System.out.println("beta =" + beta);
		System.out.println("y = "+alpha+" * x/"+beta+"+x");
	}
	}
