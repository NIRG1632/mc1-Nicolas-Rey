package taller1;

import java.util.Scanner;

public class Taller18B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double sumatoriaxlog=0;
		double sumatoriaylog=0;
		double alphalog=0;
		double betalog=0;
		double xlog=0;
		double ylog=0;
		double multiplicacionlog=0;
		double sumatoriamultiplicacionlog=0;
		double promedioxlog=0;
		double promedioylog=0;
		double a0log=0;
		double a1log=0;
		double logxala2=0;
		double sumatorialogxala2=0;
		
		
		Scanner sc = new Scanner(System.in);
		
		double xdellog[]= {2,3,4,5,6,7,8,9,10};
		double ydellog[]= {1,1.2,1.5,2.1,2.8,3.8,5,6.5,8.5};
		
		
		
		for(int i =0; i<xdellog.length;i++) {
			
			xlog=Math.log10(xdellog[i]);
			sumatoriaxlog=sumatoriaxlog+xlog;
			logxala2=Math.log10(xdellog[i])*Math.log10(xdellog[i]);
			sumatorialogxala2=sumatorialogxala2+logxala2;
			
		}
		
		promedioxlog=sumatoriaxlog/xdellog.length;
		
				
		for(int i =0; i<ydellog.length;i++) {
			
			ylog=Math.log10(ydellog[i]);
			sumatoriaylog=sumatoriaylog+ylog;
		}
		
		promedioylog=sumatoriaylog/ydellog.length;
		
		for(int i=0; i<xdellog.length;i++) {
			
			multiplicacionlog=Math.log10(ydellog[i])*Math.log10(xdellog[i]);
			sumatoriamultiplicacionlog=sumatoriamultiplicacionlog+multiplicacionlog;
		}
		
		a1log=(xdellog.length*sumatoriamultiplicacionlog-sumatoriaxlog*sumatoriaylog)/(xdellog.length*sumatorialogxala2-(sumatoriaxlog*sumatoriaxlog));
		a0log=promedioylog-a1log*promedioxlog;
		alphalog=Math.pow(10, a0log);
		betalog=a1log;
		System.out.println("ECUACION DE POTENCIAS");
		System.out.println("  ");
		System.out.println(" ao = " +a0log);
		System.out.println(" a1 = " +a1log);
		System.out.println("se aplica la transformacion");
		System.out.println("alpha =" + alphalog);
		System.out.println("beta =" + betalog);
		System.out.println("y = "+alphalog+"* x^"+betalog);
		System.out.println("  ");
		
	}
	}
