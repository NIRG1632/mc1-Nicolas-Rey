package taller1;

import java.util.Scanner;

public class Taller19 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double sumatoriax=0;
		double sumatoriay=0;
		double xporx=0;
		double sumatoriax2=0;
		double promediox=0;
		double promedioy=0;
		double multiplicacion=0;
		double sumatoriamultiplicacion=0;
		double a1=0;
		double a0=0;
		double st=0;
		double sr=0;
		double sumatoriast=0;
		double sumatoriasr=0;
		double sy=0;
		double syx=0;
		double r=0;


		Scanner sc = new Scanner(System.in);
		double x[]= {1,3,5,7,9,11,13};
		double y[]= {0.3,0.7,1.7,3.5,5.5,27.5,38.5};

		for(int i =0; i<x.length;i++) {
			sumatoriax=sumatoriax+x[i];
			xporx=x[i]*x[i];
			sumatoriax2=xporx+sumatoriax2;
		}
		promediox=sumatoriax/x.length;


		for(int i =0; i<y.length;i++) {
			sumatoriay=sumatoriay+y[i];
		}promedioy=sumatoriay/y.length;

		for(int i=0; i<x.length;i++) {
			multiplicacion=x[i]*y[i];
			sumatoriamultiplicacion=sumatoriamultiplicacion+multiplicacion;
		}
		a1=(x.length*sumatoriamultiplicacion-sumatoriax*sumatoriay)/(x.length*sumatoriax2-(sumatoriax*sumatoriax));
		a0=promedioy-a1*promediox;
		
		for(int i =0; i<y.length;i++) {
		st=Math.pow(y[i]-promedioy, 2);
		sr=Math.pow(y[i]-a0-a1*x[i], 2);
		sumatoriast=sumatoriast+st;
		sumatoriasr=sumatoriasr+sr;
		}
		sy=Math.sqrt(sumatoriast/(x.length-1));
		syx=Math.sqrt(sumatoriasr/(x.length-2));
		r=Math.sqrt((sumatoriast-sumatoriasr)/sumatoriast)*100;
		System.out.println(" ao = " +a0);
		System.out.println(" a1 = " +a1);

		System.out.println("y= "+a0 + " + " + a1 + "x");
		System.out.println(" st = " +sumatoriast);
		System.out.println(" sr = " +sumatoriasr);
		System.out.println(" sy = " +sy);
		System.out.println(" sy/x = " +syx);
		System.out.println(" r = " +r+"%");
}
}