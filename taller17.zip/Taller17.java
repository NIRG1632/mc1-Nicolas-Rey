package taller1;

import java.util.Scanner;

public class Taller17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double sumatoriax=0;
		double sumatoriay=0;
		double xporx=0;
		double sumatoriax2=0;
		double promediox=0;
		double promedioLny=0;
		double multiplicacion=0;
		double sumatoriamultiplicacion=0;
		double a1=0;
		double a0=0;
		double lny=0;
		double sumatoriaLny=0;
		double alpha=0;
		double beta=0;
		
		
		Scanner sc = new Scanner(System.in);
		double x[]= {1.2,2.4,3.6,4.8,6,7};
		double y[]= {0.8,1,1.5,2,2.9,3.6};
		double ydeln[]= {0.8,1,1.5,2,2.9,3.6};
		
		for(int i =0; i<x.length;i++) {
			sumatoriax=sumatoriax+x[i];
			xporx=x[i]*x[i];
			sumatoriax2=xporx+sumatoriax2;
		}
		promediox=sumatoriax/x.length;
		
				
		for(int i =0; i<y.length;i++) {
			sumatoriay=sumatoriay+y[i];
		}
		
		
		for(int i=0; i<x.length;i++) {
			multiplicacion=x[i]*Math.log(ydeln[i]);
			sumatoriamultiplicacion=sumatoriamultiplicacion+multiplicacion;
		}
		for(int i=0; i<x.length;i++) {
			lny=Math.log(ydeln[i]);
			sumatoriaLny=sumatoriaLny+lny;
		}promedioLny=sumatoriaLny/ydeln.length;
		
		a1=(x.length*sumatoriamultiplicacion-sumatoriax*sumatoriaLny)/(x.length*sumatoriax2-(sumatoriax*sumatoriax));
		a0=promedioLny-a1*promediox;
		System.out.println(" ao = " +a0);
		System.out.println(" a1 = " +a1);
		System.out.println(a0 + " + " + a1 + "x");
		alpha=Math.pow(Math.E, a0);
		beta=a1;
		System.out.println("se aplica la transformacion inversa");
		System.out.println("alpha =" + alpha);
		System.out.println("beta =" + beta);
		System.out.println("y = "+alpha+"e^"+beta+"x");
	}
	}
